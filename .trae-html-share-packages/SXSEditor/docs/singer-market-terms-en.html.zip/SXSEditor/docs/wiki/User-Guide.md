# User Guide

Complete documentation of all SXSEditor features.

## Table of Contents

1. [Main Window](#main-window)
2. [Singer Management](#singer-management)
3. [Singer Market](#singer-market)
4. [Singer Creator](#singer-creator)
5. [Audio Preprocessing](#audio-preprocessing)
6. [Fragment Timeline](#fragment-timeline)
7. [Accompaniment Tracks](#accompaniment-tracks)
8. [Fragment Editor (Piano Roll)](#fragment-editor-piano-roll)
9. [MIDI Editing](#midi-editing)
10. [Note Context Menu](#note-context-menu)
11. [Lyrics and Phonemes](#lyrics-and-phonemes)
12. [Pitch Curves](#pitch-curves)
13. [F0 Smoothing and Spectral Post-Processing](#f0-smoothing-and-spectral-post-processing)
14. [Alignment Guides Between Notes and the Lane](#alignment-guides-between-notes-and-the-lane)
15. [Volume and Pan Envelopes](#volume-and-pan-envelopes)
16. [Synthesis and Playback](#synthesis-and-playback)
17. [Export](#export)
18. [Audio to MIDI](#audio-to-midi)
19. [MIDI Import](#midi-import)
20. [Settings](#settings)
21. [Model Download](#model-download)
22. [Resource Manager](#resource-manager)
23. [Themes](#themes)
24. [Project Files](#project-files)
25. [Keyboard Shortcuts](#keyboard-shortcuts)
26. [Uninstall](#uninstall)

---

## Main Window

The main window is the central hub. It contains:

### Toolbar (Top)

| Control | Description |
|---------|-------------|
| ▶ Play / ⏸ Pause / ⏹ Stop | Playback controls for the entire project |
| Time Display | Shows current playback position (mm:ss:ms) |
| BPM | Beats per minute (1–999). Default: 120 |
| Time Signature | Numerator / Denominator (e.g., 4/4) |
| Auto Shift | When enabled, notes in newly created fragments auto-align to beat boundaries |
| 📂 Load | Open an existing `.sxsproj` or `.sxs` project file |
| 📤 Export | Synthesize and export the entire project as WAV |
| 🎵 Audio to MIDI | Convert an audio file to MIDI notes (see [Audio to MIDI](#audio-to-midi)) |
| Version Display | Shows the current app version |

> **Saving the project file** is done via the **File menu** (Ctrl+S / Ctrl+Shift+S), not a toolbar button. See [Save Logic](#save-logic) for the complete save behavior.

### Singer Panel (Left)

Lists all singers in the project. Each singer row shows:
- Singer name and color/avatar
- A **+** button to add fragments to this singer
- A context menu (right-click) for singer operations

### Fragment Timeline (Right)

A canvas-based timeline showing all fragments arranged by time. Each fragment is a colored rectangle representing a segment of music.

- **Double-click** a fragment to open the Fragment Editor.
- **Drag** a fragment to move it in time or across singers.
- **Drag edges** to resize a fragment.
- The playhead shows the current playback position.

---

## Singer Management

### Adding a Singer

Click the **+** button in the singer panel header. A dialog offers:

- **Open Singer Creator**: Create a new singer from scratch.
- **Open Existing Singer File**: Load a `.sxssinger` file from disk.
- **Open Singer Market**: Browse and download community-created singers (see [Singer Market](#singer-market)).

### Singer Status Indicators

- Normal: Singer loaded and ready.
- ⚠ Singer file not found: The `.sxssinger` file was moved or deleted. Use **Relocate** to point to the new location.

### Deleting a Singer

Right-click a singer and select **Delete Singer**. This removes the singer and all its fragments from the project.

### Singer File Validation

When loading a `.sxssinger` file, SXSEditor validates:
- File format and version compatibility
- Required fields (name, reference audio)
- Data integrity (MIDI notes, F0 data)

Validation errors are shown in a report dialog. Warnings indicate non-critical issues (e.g., missing optional fields, version mismatch).

---

## Singer Market

The Singer Market lets you browse and download community-created singers without leaving the app. Instead of creating a singer from your own reference audio, you can pick from a library of pre-made voices shared by other users.

### Opening the Singer Market

Open it from the singer panel — click the **+** button and choose **Open Singer Market** (in addition to the Singer Creator and existing file options).

### Browsing Singers

The Singer Market window displays available singers with:
- Singer name and avatar
- Description and tags
- Download status

### Downloading a Singer

1. Click **Download** on a singer card.
2. The singer file (`.sxssinger`) is downloaded and automatically loaded into your project.
3. The singer appears in the singer panel and is ready to use immediately.

### Sharing Your Own Singers

Singers you create in the Singer Creator can be shared to the Singer Market, allowing other users to discover and use your voice profiles.

---

## Singer Creator

The Singer Creator is a dedicated window for creating new singers. It has three sections:

### Basic Info

- **Singer Name**: Required. Used for display and file naming.
- **Avatar**: Choose between:
  - **Color**: A solid color used as the singer's identifier on the timeline.
  - **Image**: Upload a picture file (any common image format).

### Reference Audio (WAV)

Upload a WAV file that serves as the voice reference for the SVS model.

**Requirements**:
- **Format**: `.wav` only
- **Duration**: Maximum 30 seconds. If exceeded, a trim dialog opens.
- **Content**: **Pure vocals only.** This is the most important requirement.
  - No background music
  - No instrumental accompaniment
  - No reverb, echo, or other audio effects
  - No multiple voices
  - Clean, dry vocal recording only
- **Sample Rate**: 44100 Hz recommended (other rates are accepted)
- **Quality**: Minimal background noise, clear articulation

**Why pure vocals matter**: The model learns voice characteristics from this audio. Any non-vocal content (music, noise, effects) will be learned as part of the voice and will appear as artifacts in synthesized output.

After uploading:
- A waveform visualization appears.
- **Preview** button plays the audio.
- **Clear** button removes the audio and lets you upload a different file.

### WAV Trim Dialog

If the WAV file exceeds 30 seconds:
- A waveform with a selection overlay appears.
- **Drag** the selection to choose which 30-second segment to use.
- **Drag edges** of the selection to adjust start/end.
- Enter exact values in the **Start Position** and **Clip Length** fields.
- **Preview Clip** plays the selected segment.
- **Confirm Trim** applies the trim.
- **Cancel** discards the file entirely.

### Singer Preview

The right panel shows a live preview of how the singer will appear:
- Avatar (color or image)
- Singer name
- WAV status badge (✓ when audio is loaded)
- Preprocess status badge (✓ when preprocessing is complete)

### Audio Preprocessing

Click **Start Audio Preprocessing** to open the preprocessing window. This step extracts musical data from the reference audio. See [Audio Preprocessing](#audio-preprocessing).

### Creating and Saving

Click **Create & Save** (✓):
- Requires a WAV file to be loaded.
- If preprocessing was completed, the preprocessed data is included.
- Saves as a `.sxssinger` file (JSON format with base64-encoded audio).

---

## Audio Preprocessing

The Audio Preprocessing window extracts MIDI notes and F0 (fundamental frequency) data from the reference audio. This data is used by the SVS model to understand the singer's vocal characteristics.

### Window Layout

- **Top**: WAV waveform display with playback controls.
- **Middle**: MIDI editor canvas showing extracted notes.
- **Bottom**: F0 fundamental frequency curve (read-only).

### Step 1: Extract F0

Click **RMVPE Extract F0**:
- Uses the RMVPE neural model to detect pitch from the audio.
- The F0 curve appears in the bottom panel.
- This is a read-only visualization of the detected pitch contour.

### Step 2: Extract MIDI Notes

Click **Extract MIDI**:
- Uses FCPE (recommended, ONNX-based) to detect note boundaries and pitches. Alternatively, Basic Pitch (TensorFlow.js) or RMVPE can be selected in Settings.
- Extracted notes appear on the MIDI canvas.
- Note count is displayed.

Alternatively, click **Import MIDI** to load notes from an existing `.mid` or `.midi` file. This replaces any notes currently on the canvas. Standard MIDI files (format 0/1/2, including SMPTE and multi-track) are supported; drum tracks (channel 10) are filtered out automatically.

### Step 3: Edit MIDI Notes

**This step is mandatory.** Auto-extracted MIDI is approximate. You must verify and correct it:

1. **Check each note's pitch**: Does the detected MIDI pitch match the actual sung note?
2. **Check note boundaries**: Do note starts and ends align with the actual singing?
3. **Check note count**: Are all sung notes detected? Are there false detections?

Edit operations:
- **Move notes**: Drag up/down (pitch) or left/right (timing).
- **Resize notes**: Drag the right edge.
- **Add notes**: Click on empty space.
- **Delete notes**: Select and press `Delete`.
- **Edit lyrics**: Double-click a note. **You must type the lyrics yourself** — they are not auto-detected.

### Step 4: Fill in Lyrics

**Every note must have a lyric.** The preprocessing does not detect lyrics from audio. You must manually type them:

- For **Chinese singing**: Enter Chinese characters (e.g., `我`, `你`, `好`). You may append a digit `1`–`5` after a character to force a specific tone (e.g., `你2 好3`). Pinyin is **not** accepted.
- For **English singing**: Enter the English word being sung (e.g., `hello`, `love`).
- For notes with no sung content (rests, breaths): Leave the lyric empty or use a space.

### Step 5: Save

Click **Save** (💾):
- Requires at least F0 or MIDI data to be extracted.
- Saves all preprocessed data back to the Singer Creator window.
- The Singer Creator preview updates to show "Preprocess ✓".

### Important Notes

- The F0 curve is **read-only** — you cannot edit it directly.
- MIDI note editing affects only the note data, not the F0 curve.
- If you are unhappy with the extraction results, you can re-extract (this overwrites previous results).
- The preprocessing window communicates with the Singer Creator via IPC — data is sent back when you save.

---

## Fragment Timeline

The fragment timeline in the main window shows all fragments arranged across singers and time.

### Creating Fragments

Click the **+** button on a singer row to add a new fragment. The fragment is created at the current scroll position.

### Moving Fragments

- **Drag** a fragment to move it horizontally (time) or vertically (to a different singer).
- When Auto Shift is enabled, fragments snap to beat boundaries.

### Resizing Fragments

- Drag the **left or right edge** of a fragment to change its start time or duration.
- Fragment boundaries are shown as beat positions.

### Opening the Fragment Editor

**Double-click** a fragment to open it in the Fragment Editor.

### Fragment Properties

Each fragment stores:
- Start time (in beats)
- Duration (in beats)
- Assigned singer ID
- MIDI notes with lyrics
- Pitch curve (optional)
- Volume and pan envelopes

---

## Accompaniment Tracks

In addition to vocal fragments, you can add accompaniment tracks to play backing music alongside your synthesized vocals.

### Adding an Accompaniment Track

1. Click the **+** button in the singer panel (or use the track menu) and choose **Add Accompaniment Track**.
2. An import dialog opens. Select an audio file.

### Supported Audio Formats

WAV, MP3, FLAC, OGG, M4A, AAC.

### Working with Accompaniment Tracks

- **Drag to move**: Reposition the accompaniment clip on the timeline, just like vocal fragments.
- **Per-track volume**: Each accompaniment track has its own volume control. Adjust it in the track header or inspector.
- **Multi-channel**: Multiple accompaniment tracks can coexist with vocal tracks on the same timeline.
- **Resizing**: Drag the edges of an accompaniment clip to trim it.

### Playback and Export

Accompaniment tracks play alongside vocal fragments during both preview and export. When exporting, accompaniment audio is mixed with the synthesized vocals into the final WAV file.

---

## Fragment Editor (Piano Roll)

The Fragment Editor is a dedicated window with a full-featured piano-roll editor. It opens when you double-click a fragment.

### Auto-Sync to Main Window

**Edits in the Fragment Editor are automatically synced to the main window — there is no Save button.** After any edit (MIDI notes, lyrics, pitch curve, envelopes, phoneme parameters), a 500ms debounced auto-save fires, which:

1. Sends the updated fragment data to the main process via IPC (`saveFragmentData`).
2. The main process forwards the data to the main window (`fragmentDataSaved` event).
3. The main window updates the corresponding fragment in `trackManager.fragments`, refreshes the timeline (`refreshAll`), and auto-saves the project file (if a `.sxsproj` path is already set).

**Ctrl+S** in the Fragment Editor cancels the debounce timer and pushes the update immediately (force-sync). This is optional — the auto-save already handles sync.

### Window Layout

- **Toolbar** (top): Play, Export, Import MIDI, mode switching, close.
- **Piano keys** (left): Vertical pitch reference.
- **Piano roll** (center): The main editing canvas.
- **Inspector** (right): Shows properties of the selected note or singer info.
- **Parameter panel** (bottom): VOL, PAN, Phoneme, and (future) Timbre lanes.
- **Status bar** (bottom): Shows pipeline status, sample rate, hop size, and auto-sync indicator.

### Toolbar Controls

| Control | Description |
|---------|-------------|
| ▶ Play | Synthesize and play this fragment |
| ⏸ Stop | Stop playback |
| 💿 Export | Export this fragment as WAV |
| 🎵 Import MIDI | Import a standard MIDI file |
| Auto Shift | Auto-align notes to beat grid |
| MIDI button (1) | Switch to MIDI editing mode |
| Pitch button (2) | Switch to pitch curve editing mode |
| ⌨ (F1) | Show keyboard shortcuts overlay |
| ✖ Close | Close the fragment editor (auto-syncs before closing) |

### Inspector Panel

The right-side inspector shows:

- **Singer info**: Name, avatar, and description of the assigned singer.
- **Note properties** (when a note is selected):
  - Pitch (MIDI note name and frequency)
  - Start position (in beats)
  - Duration (in beats)
  - Lyric (editable text field)
- **Phoneme info**: Auto-generated phoneme breakdown for the selected note.

### Parameter Panel

The bottom panel has tabs for different parameter lanes:

- **VOL**: Volume envelope curve.
- **PAN**: Stereo pan envelope curve.
- **Phoneme**: Phoneme-level editing (duration ratios, per-phoneme volume, lock).
- **Timbre**: F0 smoothing / spectral post-processing automation. Each of the seven parameters (three F0, four Mel) has its own curve — see [F0 Smoothing and Spectral Post-Processing](#f0-smoothing-and-spectral-post-processing).

---

## MIDI Editing

### Adding Notes

- **Click** on empty space in the piano roll to create a note.
- **Drag** while clicking to set the initial note length.
- Notes snap to the beat grid based on the current zoom level.

### Selecting Notes

- **Click** a note to select it (deselects others).
- **Ctrl+click** to toggle a note's selection state.
- **Shift+click** to add a note to the current selection.
- **Middle-click drag** to box-select notes within a rectangle.
- **Shift+middle-click drag** to append a box selection.
- **Ctrl+A** to select all notes.
- **Escape** to deselect all.

### Moving Notes

- **Drag** a selected note to move it.
- **Arrow keys** (↑↓): Move selected notes by one semitone.
- **Arrow keys** (←→): Move selected notes by one time unit.
- **Shift+↑↓**: Move by one octave (12 semitones).
- **Shift+←→**: Move by one beat.

### Resizing Notes

- Drag the **right edge** of a note to change its duration.

### Deleting Notes

- Select notes and press **Delete**.

### Duplicating Notes

- Select notes and press **Ctrl+D**. Duplicates are placed after the originals.

### Editing Lyrics

- **Double-click** a note to edit its lyric inline.
- Type the lyric and press **Enter** to confirm, or **Escape** to cancel.
- You can also edit lyrics in the Inspector panel's lyric field.

---

## Note Context Menu

Right-click a note (or a selection of notes) in the Fragment Editor to open the context menu, which provides quick access to expressive controls:

### Vibrato

- Apply a vibrato effect to the selected note(s). The vibrato is rendered as a periodic pitch oscillation on the pitch curve.
- Adjustable parameters include vibrato rate (speed) and depth (amplitude).

### Fade In / Fade Out

- Apply gradual volume fades to the beginning (fade in) or end (fade out) of the selected note(s).
- These fades are applied as envelope points on the volume envelope, so they remain editable after creation.

### Other Context Menu Options

- **Reset modifications**: Clear vibrato and fade adjustments for the selected note(s).
- Standard operations (copy, paste, delete, duplicate) are also available from the context menu.

---

## Lyrics and Phonemes

### Lyric Input Rules

- **Chinese**: Enter Chinese characters (e.g., `你好世界`). You may append a digit `1`–`5` after a character to force a specific tone (e.g., `你2 好3`), where 1–4 are the four tones and 5 is the neutral tone (轻声). The system uses `pinyin-pro` to convert characters to Pinyin (with the forced tone if a digit is present), then to `zh_*` phonemes. Pinyin text (e.g., `ni hao`) is **not** accepted as Chinese — ASCII input is routed to the English G2P path.
- **English**: Enter standard English words (e.g., `hello`, `love`). The system uses a built-in CMU pronunciation dictionary (126,000 words) to convert to phonemes. Unknown words fall back to letter-by-letter phoneme estimation.
- **Continuation (slur)**: Type a half-width dash `-`. The note extends the previous note's phoneme without a new attack (noteType 3).
- **Rest**: An empty lyric is a *rest*, not a slur — it always sings as silence, whether or not the note has a pitch. (New notes start out with the default lyric `la`; clearing it makes the note silent.) Typing the literal token `<SP>` forces the silence phoneme (noteType 1).
- **Aspiration**: Type the literal token `<AP>` for an audible breath — the note keeps its slot but is sung unvoiced (noteType 2, f0 = 0).
- **noteType summary**: `1` = silence (`<SP>`), `2` = normal sung note (including `<AP>`), `3` = slur (`-`). The type is derived from the lyric automatically — you never set it by hand.

### Phoneme Editing

Switch to Phoneme mode (press `5` or click the Phoneme tab):

- **View phonemes**: Each note is automatically split into its constituent phonemes.
- **Adjust boundaries**: Drag the boundary between two phonemes to change their relative duration. The total note duration stays the same.
- **Adjust volume**: Click a phoneme and drag up/down to change its relative volume.
- **Lock phonemes**: Right-click a phoneme to toggle lock (marked with "L"). Locked phonemes are not affected by auto-adjustment when you edit lyrics.

### Slur Notes

A **slur** (continuation) note is a note that continues the previous note's sound without re-attacking. To create a slur:
- Add a note and type a half-width dash `-` as its lyric. It will be treated as a continuation of the previous note.

> **Empty lyric ≠ slur.** An empty lyric is a *rest* and always sings as silence, whether or not the note has a pitch. Typing `-` is the only way to mark a continuation.

### Kanji / Kana Auto-Grouping

When a fragment already contains Japanese kana (hiragana or katakana) in any note's lyric, every single-character kanji note in the same fragment is **automatically treated as Japanese** and split into an ordered group of kana notes. This avoids the ambiguity of using the same CJK ideographs for both Chinese and Japanese within one fragment.

- **Visual bracket** — a horizontal bracket is drawn above the group with the original kanji displayed in the middle, so you can always see which kana belong to which kanji.
- **Strict ordering** — the converted kana keep their dictionary order. You cannot insert other MIDI notes inside a group's time span.
- **Movement** — kana notes can be moved in pitch and time, but they cannot be deleted individually.
- **Whole-group deletion** — deleting any kana in a group removes the entire group (all kana in that kanji).
- **Right-click toggle** — right-click the bracket, the kanji label, or any kana inside the group to open the *Kanji Settings* menu. Choose **Set as Chinese** to merge the whole group back into a single kanji note (length = total group span, pitch = right-clicked note's pitch); choose **Set as Japanese** to split it again.
- **Manual override persists** — once you manually set a kanji to Chinese, it will not be auto-split again even if the fragment still contains kana.

---

## Pitch Curves

Pitch curves add vibrato, pitch slides, and other expressive effects on top of the base MIDI pitch.

### Switching to Pitch Mode

Press `2` or click the **Pitch** button in the toolbar. The pitch curve editing tools appear.

### Anchor Points

- **Click** to add an anchor point on the pitch curve.
- **Drag** an anchor to move it (changes both time and pitch offset).
- **Right-click** an anchor to delete it.
- **Select** anchors with box-select (middle-click drag).
- **Delete** selected anchors with the Delete key.
- **Arrow keys** move selected anchors.

### Brush Mode

- **Shift+drag** to draw freehand pitch curves.
- The **Smoothing** slider (0–100) controls how much brush strokes are smoothed. Higher = smoother curves.

### Anchor Strength and Smoothing

Every anchor carries two extra properties beyond time and pitch:

| Property | Range | Meaning |
| --- | --- | --- |
| **Strength** | 0–100 (default 100) | How hard the anchor pulls the curve. 100 = the curve passes exactly through the anchor (legacy behaviour). 0 = the anchor is ignored and the curve becomes the straight line between its neighbours. The first and last anchor have no two-sided neighbours, so strength does not apply to them. |
| **Smoothing** | 0–100 (default 30) | Shape of the segment leaving this anchor: 0 = linear ramp, 100 = full ease-in/ease-out (smoothstep). Taken from the anchor on the left of each segment. |

- **Right-hold and drag** an anchor: left/right adjusts **strength**, up/down adjusts **smoothing**. A HUD next to the cursor shows both numbers live and the curve redraws as you drag.
- **Right-click** an anchor opens the menu with a strength slider, a smoothing slider with presets, and delete.
- When strength is below 100, a dashed guide links the anchor to where the curve actually runs, so the pull is visible.

### Reset

Click **↺ Reset** to clear all pitch curve modifications and return to the auto-generated curve based on MIDI notes.

### Pitch Curve Data

The pitch curve consists of:
- **Anchor points**: Fixed points with time and pitch offset values.
- **Brush segments**: Freehand-drawn segments (stored as sequences of points).

The final pitch is: MIDI note pitch + pitch curve offset.

---

## F0 Smoothing and Spectral Post-Processing

The **Timbre** lane (bottom parameter panel, press `6`) exposes seven post-processing parameters that clean up three common neural-vocal artefacts: frame-to-frame pitch jitter, mechanical pitch steps at note changes, and harsh high-frequency edges in the spectrogram.

All seven are **off by default**, so existing projects sound exactly as before until you enable something.

### Two Groups, Two Stages

| Group | Runs in | Affects |
| --- | --- | --- |
| **F0** (smoothing, outlier removal, transition overshoot, transition length) | The editor, on the F0 curve sent to the model | Preview **and** export identically |
| **Spectral** (spectral interpolation, time sigma, frequency sigma) | The inference pipeline, on the Mel spectrogram just before the vocoder | Preview **and** export identically |

Mel frame rate is 24 kHz / 480 = **50 frames per second** (20 ms per frame); frame-based values use those frames.

### Parameters

| Parameter | Range | What it does |
| --- | --- | --- |
| Smoothing (F0) | 0–100% | Blends the raw F0 with a Savitzky-Golay filtered copy (7-frame window, cubic order). The local polynomial fit keeps the overall pitch trend (vibrato, drawn slides) while removing frame-to-frame jitter. Runs in the cents domain and never crosses a silent gap. |
| Outlier removal (F0) | 0–9 frames | Median filter window. Removes isolated pitch spikes (octave errors, detector glitches) without smearing the note. 0 = off; 3–5 is typical. |
| Transition overshoot (F0) | 0–100% | At every detected pitch jump the step is replaced by a cubic Bezier that overshoots the target and settles back, like a singer leaning into a leap. A candidate must pass two checks so natural vibrato is never touched: adjacent frames differ by more than 50 cents, and the median level well before/after the jump differs by at least 75 cents (vibrato oscillates back to its midline; a step does not). Higher = more overshoot (up to 35% of the interval). 0 leaves the jump untouched. |
| Transition length (F0) | 0–300 ms | Duration of the Bezier transition. Only meaningful when overshoot is above 0. |
| Spectral interpolation (mel) | 0–100% | At every note / phoneme boundary, frames in a +/-3-frame window are blended toward the linear interpolation of the spectra on both sides, weighted by a raised cosine. The spectral envelope then changes continuously across the transition instead of jumping in one frame. |
| Time-freq smoothing, time (mel) | 0–6 sigma | Gaussian sigma along the Mel time axis. Light values (0.8–1.5) tame diffusion grit and breath noise; large values blur consonants. |
| Time-freq smoothing, freq (mel) | 0–6 sigma | Gaussian sigma along the Mel frequency axis. Smooths harmonic edges and removes the buzzy high-frequency fringe. |

### One Curve per Parameter

The seven values are **not** drawn on one shared lane — percentages, integer frame counts and Gaussian sigmas have different units and ranges. Each parameter owns its own automation curve:

- The **chips** in the lane header (grouped *F0 smoothing* / *Spectral*) switch the active curve; the lane always shows only the active parameter, in its own units.
- An **empty curve means "constant"** — the value comes from the inspector slider. Add an anchor and the curve takes over between the first and last anchor; outside that span the endpoint value holds.
- The inspector banner reads **Manual** (constant) or **Auto** (curve active).

### Editing the Curves

- **Click** empty lane space to add an anchor at that time and value.
- **Drag** an anchor: left/right changes time, up/down changes value (quantised to the parameter step).
- **Right-hold and drag**: left/right changes **strength**, up/down changes **smoothing**, with a live HUD and instant curve update.
- **Shift+right-click** deletes an anchor; `Delete` deletes all selected anchors.
- Selecting an anchor retargets the inspector slider to *that anchor* (exact numeric input); with no anchor selected the slider edits the global constant.
- `Ctrl+Z` / `Ctrl+Y` undo and redo curve edits.

### Presets

The inspector's **Preset** dropdown writes a tested combination into the global defaults without touching anchors you have drawn:

| Preset | Smoothing / Outlier / Overshoot | Interp / sigma time / sigma freq | Typical use |
| --- | --- | --- | --- |
| Off | 0 / 0 / 0 | 0 / 0 / 0 | Bit-exact legacy output |
| Gentle | 25% / 3 / 20% | 25% / 0.8 / 0.4 | Light cleanup, keeps all transients |
| Standard | 50% / 3 / 35% | 45% / 1.2 / 0.6 | Good default for sung vocals |
| Strong | 80% / 5 / 55% | 70% / 2.0 / 1.0 | Very jittery takes; may dull consonants |

> These settings also apply outside the fragment editor: the main window's **Play All** and **Export All** rebuild the same per-fragment F0 curve (with F0 post-processing) and send the same spectral payload, so exported project audio matches the editor.

### Notes

- Any change to these curves invalidates the fragment's preview-audio signature, so the next playback re-synthesises instead of replaying stale audio.
- F0 settings change the F0 hash; spectral settings are hashed separately because they do not alter the F0 curve at all.
- Spectral automation is aligned to **the first note of the fragment** (the model renders from the first note, not from bar 1). If a fragment starts with a long rest, the curve's bar positions and the mel frame numbers differ by that rest, but the curve still follows wall-clock time.

---

## Alignment Guides Between Notes and the Lane

Whenever a parameter lane is open (VOL / PAN / Phoneme / Timbre), every note's **start and end** is marked with a vertical dashed line, so you can see exactly where a note begins and ends while editing the curve underneath:

- **Piano-roll area** — a faint dashed line runs from the bottom edge of each note down to the top of the lane. Notes at different pitches in the same column each draw their own segment from their own row.
- **Inside the lane** — the line continues through the full lane height at slightly higher contrast, so it survives being drawn under envelope curves and phoneme bars. A short tick at the lane's top edge keeps boundaries readable in dense content.
- Lines are pixel-snapped (half-pixel offset) so they stay crisp 1px at any zoom; inside the lane, duplicate edges (a note ending exactly where the next begins) are drawn once (in the piano-roll area each note draws its own line from its own row).
- Only notes inside the viewport are drawn, so scrolling a long fragment costs nothing extra.

---

## Volume and Pan Envelopes

### Volume (VOL)

Press `3` or click the **VOL** tab:
- The volume envelope controls loudness over time.
- Default: constant volume of 1.0 (100%).
- Click to add control points. Drag to adjust.
- Range: 0.0 (silent) to 1.0 (full volume).

### Pan (PAN)

Press `4` or click the **PAN** tab:
- The pan envelope controls stereo position.
- Default: centered (0.0).
- Range: -1.0 (full left) to 1.0 (full right).

### Envelope Editing

- **Click** on the envelope area to add a control point.
- **Drag** a point to move it.
- **Right-click** a point to delete it.
- Points are connected by smooth curves.

---

## Synthesis and Playback

### How Synthesis Works

When you press Play, SXSEditor:

1. **Prepares input**: Collects MIDI notes, lyrics, pitch curve, and singer data.
2. **Processes text**: Converts lyrics to phoneme sequences using language-specific processing.
3. **Encodes**: Runs 5 encoder models (text, pitch, note type, F0, condition embedding).
4. **Runs diffusion**: Iteratively denoises a mel spectrogram using the diffusion model.
5. **Vocalizes**: Converts the mel spectrogram to a waveform using the vocoder.
6. **Plays audio**: Outputs the waveform through the audio system.

### Preview vs Export Quality

| Parameter | Preview | Export |
|-----------|---------|--------|
| Diffusion Steps | 16 (default) | 32 (default) |
| CFG Strength | 3.0 | 3.0 |
| CFG Rescale | 0.75 | 0.75 |
| Sampler | STORK-2 (default) | STORK-2 (default) |

Preview uses fewer steps for faster response. Export uses more steps for higher quality. Both are configurable in Settings. The Sampler (diffusion ODE solver) is also configurable per path — see [Diffusion Sampler](#diffusion-sampler).

### Playback Controls

- **▶ Play**: Start synthesis and playback. On first play, the SVS pipeline initializes (loads models into GPU).
- **⏸ Pause**: Pause playback. Resume from the paused position.
- **⏹ Stop**: Stop playback and reset to the beginning. Stopping during synthesis uses cooperative cancellation (AbortController-based) — the pipeline checks for abort signals between steps and shuts down cleanly, without forcefully terminating the worker thread.

### Fragment-Level Playback

In the Fragment Editor, **▶ Play** synthesizes and plays only the current fragment. This is useful for quick previews while editing.

### Synthesis Cache

SXSEditor maintains a per-segment LRU cache (**32 entries, up to 300 MB**) for synthesis results. When you replay a fragment whose notes, lyrics, pitch curve, and singer data have not changed, the cached audio is reused instantly — no re-synthesis is needed. Editing any parameter that affects the output invalidates the relevant cache entries.

### Audio Quality Enhancements

The synthesis output benefits from several post-processing improvements:

- **EBU R128 loudness normalization**: The final mix is normalized to −14 LUFS with a true-peak limiter at −1 dBTP, ensuring consistent loudness across projects.
- **WSOLA crossfade**: At chunk boundaries (where long audio is split for processing), WSOLA (Waveform Similarity Overlap-Add) crossfading replaces the previous Hann overlap-add, producing smoother transitions.
- **Kaiser windowed-sinc resampling**: the 24 kHz model output is upsampled to the selected output rate by a band-limited Kaiser-windowed sinc interpolator for accurate high-frequency reproduction.

---

## Export

### Exporting a Fragment

In the Fragment Editor, click **💿 Export**:
1. The **Export dialog** opens, pre-filled with the export-quality parameters from Settings. You can override them for this export only: **Sampler**, Diffusion Steps, CFG Strength, CFG Rescale, Auto Shift, plus advanced options (the global Settings values are not changed).
2. After confirming, the fragment is synthesized using the chosen parameters.
3. A file save dialog appears.
4. Choose a location and filename.
5. The WAV file is saved (48 kHz and **32-bit float** by default; bit depth selectable 16 / 24 / 32-bit). Export sample rate is selectable: 24/44.1/48/96 kHz.

### Exporting the Entire Project

In the main window, click **📤 Export**:
1. The **Export dialog** opens (same options as single-fragment export: Sampler, Diffusion Steps, CFG, Auto Shift, advanced).
2. All fragments are synthesized sequentially using the chosen parameters.
3. Fragments are mixed together according to their timeline positions.
4. A file save dialog appears.
5. The mixed WAV file is saved.

### Export Progress

During export, a progress indicator shows:
- Current fragment being processed.
- Overall progress percentage.
- Status messages (preparing, synthesizing, encoding WAV, saving).

### LRC Lyrics Export

You can export the project's lyrics as a timed `.lrc` file, which is a standard format supported by most music players and karaoke software.

1. Use **File > Export LRC** (or the export menu option).
2. The lyrics from all fragments are compiled with their timing information.
3. Each line in the `.lrc` file includes a timestamp tag (e.g., `[00:12.34]`) corresponding to when that lyric is sung in the project.
4. Choose a save location for the `.lrc` file.

The LRC file can be used alongside the exported WAV file for karaoke-style lyric display.

---

## Audio to MIDI

Convert an existing audio file into MIDI notes on a new track.

### Starting Audio to MIDI

Click **🎵 Audio to MIDI** in the main toolbar. A dialog offers:

- **Extract Pitch (RMVPE)**: Extracts MIDI notes AND an F0 pitch curve. The pitch curve is applied to the fragment.
- **MIDI Only**: Extracts only MIDI notes without a pitch curve.

### Supported Audio Formats

WAV, MP3, FLAC, OGG, AAC, M4A.

### Extraction Process

1. Select an audio file.
2. The system decodes the audio.
3. Based on your Settings, one of the following extraction tools is used:
   - **FCPE** (recommended): ONNX-based, fast and accurate. Features a configurable post-processing pipeline.
   - **Basic Pitch**: Neural network-based (TensorFlow.js), stable results.
   - **RMVPE**: Converts F0 pitch curve to notes. Experimental, results may vary.
4. A new singer track and fragment are created with the extracted notes.
5. If you chose "Extract Pitch", the F0 curve is also applied as a pitch curve.

### After Extraction

- The new track has no singer file assigned. You must select a `.sxssinger` file for it before synthesis.
- Review and edit the extracted notes — auto-extraction is approximate.

---

## MIDI Import

Import a standard MIDI file into the Fragment Editor.

### Importing

1. Open a fragment in the Fragment Editor.
2. Click **🎵 Import MIDI** in the toolbar.
3. Select a `.mid` or `.midi` file.
4. The MIDI file's notes are loaded into the fragment, replacing existing notes.

### MIDI File Handling

- Standard MIDI files (format 0, 1, 2) are supported, including SMPTE time division.
- Multi-track MIDI files: all non-drum tracks are merged onto a single timeline. Drum tracks (MIDI channel 10) are automatically filtered out.
- Lyrics from MIDI (meta event 0x05) are preserved if present. Encoding is auto-detected (BOM/UTF-8/legacy charset) for correct display of non-ASCII lyrics.
- Note timing is converted to the project's BPM.

---

## Settings

Open Settings from the menu bar: **SXSEditor > Settings**.

### General

#### Language
- **Chinese (简体)** / **English**
- Requires app restart to take effect.

#### Theme
- Select from built-in and user themes.
- Changes apply immediately to all windows (hot-swap, no restart needed).
- See [Themes](#themes) for details.

### Inference

#### Inference Hardware

Configure which hardware devices are used for neural network inference.

**Device Modes**:
- **Smart Mode** (recommended): Automatically selects the best device and assigns models optimally. Prefers discrete GPU; falls back to integrated GPU or CPU.
- **Manual Mode**: Specify a single device for all models.
- **Advanced Mode**: Assign different devices to different model groups (SVS Diffusion, SVS Encoder, SVS Auxiliary, RMVPE).

**Available devices**:
- Discrete GPU (NVIDIA, AMD, Intel) via DirectML
- Integrated GPU via DirectML
- NPU via WebNN
- CPU (fallback)

**WebNN/NPU Status**: The settings page shows whether WebNN and NPU are available on your system.

#### Preview Inference Parameters

Used when playing back in the editor (fast preview):

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| Diffusion Steps | 16 | 4–64 | Fewer steps = faster, lower quality |
| CFG Strength | 3.0 | 0–10 | Higher = more aligned with conditions. 0 = skip unconditional prediction (2x speed) |
| CFG Rescale | 0.75 | 0–1 | Mitigates over-guidance artifacts |
| Sampler | STORK-2 | Euler / Heun / Extrapolated Euler / STORK-2 | Diffusion sampling solver (default: STORK-2). See [Diffusion Sampler](#diffusion-sampler) below. |

#### Export Inference Parameters

Used when exporting WAV files (high quality):

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| Diffusion Steps | 32 | 4–64 | More steps = higher quality |
| CFG Strength | 3.0 | 0–10 | Same as preview |
| CFG Rescale | 0.75 | 0–1 | Same as preview |
| Sampler | STORK-2 | Euler / Heun / Extrapolated Euler / STORK-2 | Diffusion sampling solver (default: STORK-2). The export dialog also lets you override this per export. |

#### Diffusion Sampler

The diffusion model iteratively denoises a mel spectrogram by integrating the flow-matching velocity-field ODE. The **sampler** is the ODE solver that decides how each denoising step combines model evaluations (NFE = number of function evaluations) into the state update. Four samplers are available, selectable independently for preview and export:

| Sampler | NFE / step | Description |
|---------|------------|-------------|
| **Euler** | 1 | First-order explicit Euler, midpoint time evaluation. The original baseline; fastest and most predictable. |
| **Heun** | 2 | Second-order improved Euler (trapezoidal rule). Higher accuracy, roughly 2× inference time. Falls back to Euler on the final step to avoid evaluating `t > 1`. |
| **Extrapolated Euler** | 1 | Velocity-extrapolation heuristic inspired by STORK (ICLR 2026). Reuses the previous step's velocity for linear extrapolation. Not the full stabilized RK formulation; benefit is heuristic and strongest when the velocity field changes smoothly. Falls back to Euler when extrapolation is unsafe (amplitude / sign-flip / NaN guards). |
| **STORK-2** (default) | 1 | Paper-faithful Stabilized Taylor Orthogonal Runge-Kutta (Tan et al., ICLR 2026, arXiv:2505.24210). Runge-Kutta-Gegenbauer 2nd-order recurrence with 8 sub-stages and Taylor-expansion virtual NFE. Designed for stiff ODEs with an extended stability region (~2s² = 128×). Tradeoff: higher per-step algebraic cost than Euler. |

> **Note**: Extrapolated Euler and STORK-2 carry cross-step velocity state. In **chunked preview inference** (long fragments split into chunks), this state resets at every chunk boundary, reducing their benefit — for chunked previews, Euler or Heun is usually the safer choice. The sampler setting is stored in `previewSampler` / `exportSampler`; the legacy value `stork` is silently mapped to `extrap` for backward compatibility.

#### NPU Inference Settings

Only relevant when using NPU (WebNN) for inference:

| Parameter | Default | Description |
|-----------|---------|-------------|
| Diffusion Batch Size | 4 | Batch size for diffusion model. batch=4 processes 2 segments simultaneously. |
| Vocoder Batch Size | 4 | Batch size for vocoder. batch=4 processes 4 audio chunks simultaneously. |

These settings only affect the NPU path. DirectML and CPU paths are unaffected.

#### Dynamic Thresholding

Per-frame percentile clipping (Imagen, arXiv:2205.11487) that suppresses outlier mel bins during diffusion sampling, reducing artifacts without sacrificing detail.

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| Percentile | 0.999 | 0.9–0.999 | Higher = less clipping (more detail preserved). Lower = more aggressive artifact suppression. |

When enabled, each diffusion step clips mel bins that exceed the specified percentile threshold before the next step. This is applied independently for both preview and export paths.

#### CFG Schedule

Controls how the CFG (Classifier-Free Guidance) strength varies across diffusion steps, instead of using a constant value:

| Mode | Description |
|------|-------------|
| **Constant** (default) | CFG strength stays the same for all steps. Equivalent to the previous behavior. |
| **Linear** | CFG strength ramps linearly from an initial value to the target value across steps. |
| **Cosine** | CFG strength follows a cosine schedule, smoothing the transition. |
| **Custom** | Define a custom schedule via keyframes. |

The schedule mode can be set independently for preview and export.

#### Vocoder Overlap Frames

Controls the number of overlapping frames used at vocoder chunk boundaries for smooth crossfading:

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| Overlap Frames | 32 | 8–96 | More frames = smoother transitions but slightly slower. Previous default was 8. |

### Audio

#### Output Mode
- **Shared Mode** (WASAPI Shared): Standard Windows audio. Other apps can play audio simultaneously.
- **Exclusive Mode** (WASAPI Exclusive): Selectable in Settings for future support, but not implemented in the current version — the decibri backend ignores the exclusive-mode flag and always opens the device in shared mode.

#### Output Device
- **System Default** or a specific audio device.
- Playback currently always uses WASAPI shared mode.

#### Sample Rate
Options: 22050, 24000 (native), 44100, 48000 (default), 96000, 192000 Hz.
- The default is 48 kHz (changed from 24 kHz in earlier versions). The SVS model runs at 24 kHz internally and the output is upsampled to the selected rate with a band-limited Kaiser windowed-sinc interpolator.
- Because playback always runs in shared mode, the app resamples the synthesized audio to the selected rate itself.

#### Bit Depth
Options: 32-bit Float (recommended), 32-bit Integer, 24-bit Integer, 16-bit Integer.
- Applies to the playback stream in shared mode too; the backend supports only int16 / float32, so 24-bit and 32-bit Integer fall back to 32-bit Float.

#### Buffer Size
Options: 64 to 4096 samples.
- Smaller = lower latency but higher CPU load and risk of audio glitches.
- Currently not forwarded to the device (the decibri backend ignores buffer size).

#### Master Volume
Slider from 0% to 100%.

### Audio: MIDI Extraction Tool

- **FCPE** (recommended): ONNX-based MIDI extraction with a configurable post-processing pipeline. Fast and accurate.
- **Basic Pitch**: Neural network-based MIDI extraction (TensorFlow.js).
- **RMVPE (experimental)**: F0-to-notes conversion. May produce suboptimal results.

### Model

#### Model Precision

Select which precision of ONNX models to use:
- FP16, FP32, INT8, INT8-NPU
- Different precisions are stored independently and coexist.
- Switching does not require re-downloading — each precision has its own subdirectory.
- See the precision info box in Settings for detailed descriptions.

#### Model Status

A list shows the status of each model group:
- ✅ Ready: All files present.
- ❌ N files missing: Some model files are not downloaded.

#### Open Model Download

Opens the model download window to download or update model files for the selected precision.

---

## Model Download

The Model Download window handles downloading ONNX model files from ModelScope.

### When It Appears

- Automatically on first launch if models are missing.
- Manually from Settings > Model > **Open Model Download**.
- When switching to a precision whose models haven't been downloaded yet.

> **Note**: The model download directory defaults to a location that does not require admin privileges. You can change it using the **Change** button.

### Features

- **Precision selection**: Choose which precision to download.
- **Download directory**: Default is the app's model directory. Click **Change** to select a different location.
- **Parallel download**: Up to 16 concurrent chunked connections per file.
- **Progress tracking**: Per-file and overall progress bars.
- **Speed display**: Current download speed.
- **Resume support**: Re-running the download skips completed files.

### Model Groups

| Group | Required | Description |
|-------|----------|-------------|
| SVS Synthesis Pipeline | Yes | Core models for singing synthesis (9 models) |
| RMVPE Pitch Detection | No | F0 extraction for audio preprocessing |
| FCPE MIDI Extraction | No | ONNX-based MIDI note extraction (recommended) |
| Basic Pitch MIDI Extraction | No | MIDI note extraction from audio (TensorFlow.js) |
| RosVot MIDI Recognition | No | (Currently disabled) Advanced MIDI extraction |
| SVS Japanese Models | No | Japanese-specific encoder and preflow models |

---

## Resource Manager

Open from the menu bar: **Settings > Resource Manager**.

### GPU Info

Shows detected GPU devices:
- Device name and type (Discrete/Integrated)
- VRAM usage (used/total)

### Model Management

Lists all loaded models with options to:
- **Load All**: Load all model groups into GPU memory.
- **Unload All**: Unload all models, freeing VRAM.
- **Load/Unload** individual model groups.

Models are automatically loaded when needed for synthesis. Unloading frees VRAM for other applications.

### Summary

Shows:
- Number of loaded models.
- Estimated VRAM usage.

---

## Themes

SXSEditor has a layered design token system with hot-swappable themes.

### Built-in Themes

| ID | Name | Description |
|----|------|-------------|
| `dark-aurora` | Aurora Dark | Default dark theme with blue-purple accents |
| `light-paper` | Paper Light | Light theme with white background |
| `midnight-amber` | Midnight Amber | Dark theme with warm amber accents |
| `acg` | ACG | Anime/game-inspired color scheme |

### Switching Themes

1. Open **Settings**.
2. Go to the **Theme** section.
3. Select a theme from the dropdown.
4. The change applies immediately to all open windows.

### Editing Themes

Click **Edit Current Theme** to open the visual theme editor:
- Tokens are organized in layers: Global, Alias, Component, Custom.
- Color tokens have HEX/RGB/HSL pickers.
- The editor has its own 20-step undo/redo stack (Ctrl+Z/Ctrl+Y).

### Importing/Exporting Themes

- **Import Theme**: Load a `.theme.json` file.
- **Export Theme**: Save the current theme to a `.theme.json` file.
- **Save As**: Create a new user theme from the current edits.

### User Theme Storage

User themes are stored in:
- Windows: `%APPDATA%\sxseditor\themes\<theme-id>.theme.json`

---

## Project Files

### Save Logic

SXSEditor has three independent save flows. Understanding them avoids confusion about what gets saved and when.

#### 1. Fragment Editor → Main Window (auto-sync, no button)

Every edit in a Fragment Editor window (MIDI notes, lyrics, pitch curve, VOL/PAN envelopes, phoneme parameters) triggers a **500ms debounced auto-save** that pushes the updated fragment data to the main window:

- **Trigger**: Any edit (note move/add/delete, lyric change, pitch anchor edit, envelope edit, phoneme adjustment, MIDI import).
- **Mechanism**: `scheduleAutoSave()` → 500ms debounce → `saveFragmentData()` → IPC `saveFragmentData` → main process → `fragmentDataSaved` event → main window updates `trackManager.fragments` and calls `refreshAll()` + `autoSaveProject()`.
- **No Save button**: The Fragment Editor toolbar does not have a Save button. Sync is fully automatic.
- **Ctrl+S** (optional): Cancels the debounce and pushes immediately (force-sync). Useful if you want to see the change on the timeline instantly without waiting 500ms.
- **Close button**: Auto-syncs before closing the window.

> **Note**: When you load a new `.sxsproj` file, all open Fragment Editor windows are closed automatically. This prevents stale windows from holding references to fragment IDs that no longer exist in the new project (which would cause edits to be silently dropped).

#### 2. Main Window → `.sxsproj` file (project file save)

- **Auto-save**: After each fragment sync (flow #1 above), the main window auto-saves to `state.currentProjectFilePath` if a path is already set (i.e., you have saved or loaded a project at least once). This is silent — no dialog.
- **Manual save** (File → Save / `Ctrl+S`): If a project path exists, writes silently to the same path. If no path exists yet, falls back to Save As.
- **Save As** (File → Save As / `Ctrl+Shift+S`): Opens a dialog with the **embed singer files** option:
  - **Embed**: Singer reference audio and preprocessed data are included in the project file. Makes the project self-contained but larger.
  - **Don't embed**: The project references external `.sxssinger` files by path. Smaller file, but requires singer files to be accessible.
- **Unsaved changes on close**: When closing the main window with unsaved changes, a dialog offers **Save & Exit**, **Don't Save**, or **Cancel**.

#### 3. Singer Creator → `.sxssinger` file (singer file save)

- **Save** (File → Save / `Ctrl+S`): Saves the singer to the existing `.sxssinger` path. If no path exists, falls back to Save As.
- **Save As** (File → Save As / `Ctrl+Shift+S`): Opens a dialog to choose a new `.sxssinger` location.
- **Create & Save** (✓ button): Creates a new singer file. Requires a WAV file to be loaded.
- **Audio Preprocessing → Singer Creator**: The preprocessing window's Save button sends extracted F0/MIDI data back to the Singer Creator via IPC (does not write a file directly).

### Loading Projects

Click **📂 Load** in the toolbar:
- Opens `.sxsproj` or `.sxs` files.
- All open Fragment Editor windows are closed before loading (see flow #1 note above).
- Fragments are normalized via `trackManager.addFragment()` to ensure all fields (`envelopes`, `pitchCurve`, etc.) are present.
- If singer files are embedded, they are loaded directly.
- If not embedded, SXSEditor attempts to load singer files from their stored paths. If files are missing, a warning appears with a **Relocate** option.

### Unsaved Changes

When closing the main window with unsaved changes, a dialog offers:
- **Save & Exit**: Save and close.
- **Don't Save**: Discard changes and close.
- **Cancel**: Stay in the app.

---

## Keyboard Shortcuts

Press **F1** in the Fragment Editor to see the full shortcuts overlay.

> Shortcuts below apply to the **Fragment Editor** window unless noted. Main window shortcuts are accessed via the File menu (Ctrl+S = Save project, Ctrl+Shift+S = Save As).

### General (Fragment Editor)

| Shortcut | Action |
|----------|--------|
| `Ctrl+Z` | Undo |
| `Ctrl+Y` | Redo |
| `Ctrl+S` | Force-sync fragment to main window (cancel 500ms debounce; auto-sync already handles this) |
| `Space` | Play / Stop |
| `1` | Switch to MIDI mode |
| `2` | Switch to Pitch mode |
| `3` | Switch to VOL mode (expands parameter panel) |
| `4` | Switch to PAN mode (expands parameter panel) |
| `5` | Switch to Phoneme mode (expands parameter panel) |
| `F1` | Show shortcuts help |

### Selection

| Shortcut | Action |
|----------|--------|
| Middle-click drag | Box select notes/anchors |
| Shift+Middle-click | Append box select |
| Ctrl+Click | Toggle selection |
| Shift+Click | Append to selection |
| `Ctrl+A` | Select all |
| `Escape` | Deselect all |

### MIDI Editing

| Shortcut | Action |
|----------|--------|
| `↑` `↓` | Move selected notes (semitone) |
| `←` `→` | Move selected notes (time unit) |
| `Shift+↑` `Shift+↓` | Move selected notes (octave) |
| `Shift+←` `Shift+→` | Move selected notes (beat) |
| `Delete` | Delete selected notes |
| `Ctrl+D` | Duplicate selected notes |
| Double-click | Edit note lyric |
| Right-click kanji / kana group | Open Kanji Settings menu (toggle Chinese / Japanese) |

### Pitch Editing

| Shortcut | Action |
|----------|--------|
| Click | Add anchor point |
| Drag anchor | Move anchor point |
| Shift+Drag | Brush mode (freehand draw) |
| Right-click | Delete anchor point |
| `Delete` | Delete selected anchors |
| `↑` `↓` `←` `→` | Move selected anchors |

### Phoneme Editing

| Shortcut | Action |
|----------|--------|
| Click phoneme + drag | Adjust phoneme volume (up/down) |
| Drag boundary | Adjust adjacent phoneme duration ratio |
| Right-click phoneme | Toggle lock (L marker) |
| `5` | Switch to phoneme mode |

### View

| Shortcut | Action |
|----------|--------|
| `Ctrl+scroll` | Horizontal zoom |
| `Shift+scroll` | Horizontal scroll |
| `Scroll` | Vertical scroll |

---

## Uninstall

The default uninstaller only removes the application itself — **downloaded models and user settings are left on disk** and must be cleaned up manually if you no longer need them. ONNX model files can total several GB, so check the model location before uninstalling.

### Step 1: Check your model download location

Before uninstalling, open SXSEditor and confirm where models are stored:

1. Open **Settings > Model** and click **Open Model Download** (or open the Model Download window from the menu).
2. The **Download directory** line shows the current model directory. Write it down or copy it.
3. If you previously clicked **Change** to redirect downloads to a custom folder, that folder is the one you must clean up — not the default location below.

### Step 2: Identify the default model location

If you never changed the download directory, models live in one of the following locations depending on how the app was installed:

| Type | Path | Removed by uninstaller? |
|------|------|-------------------------|
| Bundled models (full installer) | `<install_dir>\resources\app.asar.unpacked\onnx_models\` | Yes |
| Downloaded models (default) | `%APPDATA%\sxseditor\onnx_models\` | **No** — must delete manually |
| Custom directory | The folder you selected via **Change** | **No** — must delete manually |

On a typical Windows install, `%APPDATA%` expands to `C:\Users\<your-username>\AppData\Roaming`. You can paste `%APPDATA%\sxseditor\onnx_models` directly into the File Explorer address bar to jump there.

> **Note**: Downloaded models include subdirectories per precision: `fp16/`, `int8/`, `int8/optimized_npu/`, and a `JP/` subfolder for Japanese models. Each precision is independent, so you can delete one without affecting others.

### Step 3: Delete models to free space

If you no longer need the models, delete the entire model directory identified in Step 1 or Step 2:

- **Default location**: delete the `%APPDATA%\sxseditor\onnx_models\` folder.
- **Custom location**: delete the folder you selected via **Change**.
- **Partial cleanup**: to keep settings but remove only models, delete just the `onnx_models` subfolder and leave the rest of `%APPDATA%\sxseditor\` intact.

> **Tip**: Reinstalling later? Leave the `onnx_models` folder in place — SXSEditor will detect the existing files and skip re-downloading them.

### Step 4: Remove leftover user data (optional)

After uninstalling the app, the following user data remains in `%APPDATA%\sxseditor\`. Delete this folder if you want a fully clean removal:

| File / Folder | Purpose |
|---------------|---------|
| `settings.json` | App settings (audio, inference, theme, etc.) |
| `sxseditor-locale.json` | Language preference |
| `themes\` | User-created or imported themes |
| `onnx_models\` | Downloaded models (see Step 3) |

Leftover installer files in `%TEMP%\sxseditor-update\` are pruned automatically 7 days after they were downloaded, so no manual cleanup is required there.

### Step 5: Run the uninstaller

After backing up or deleting the data above, run the uninstaller:

1. Open **Settings > Apps > Installed apps** (Windows 11) or **Control Panel > Programs and Features** (Windows 10).
2. Find **SXSEditor** and click **Uninstall**.
3. Follow the InnoSetup wizard to complete removal.

> **Note**: The uninstaller removes the application files (including bundled models in `app.asar.unpacked\onnx_models\`) but does **not** delete `%APPDATA%\sxseditor\`. That folder must be removed manually as described in Steps 3 and 4.
