/* ==========================================================================
   SXSEditor Docs — Shared layout behavior
   - Theme toggle (persist to localStorage 'sxs-theme', auto-detect system)
   - Language button wiring (delegates to SXS_i18n.setLang)
   - Mobile nav drawer toggle
   - Scroll-aware header .scrolled state
   - IntersectionObserver fade-in for .fade-in elements
   - Copy button delegation for [data-copy] / .copy-btn
   - Smooth-scroll back-to-top button
   ========================================================================== */
(function () {
  'use strict';

  const THEME_KEY = 'sxs-theme';

  function getPreferredTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
    return (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
    // update aria-label on toggle if present
    const toggle = document.querySelector('[data-theme-toggle]');
    if (toggle) toggle.setAttribute('aria-label', theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
  }

  function initTheme() {
    applyTheme(getPreferredTheme());
    const toggle = document.querySelector('[data-theme-toggle]');
    if (toggle) {
      toggle.addEventListener('click', function () {
        const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
        applyTheme(cur === 'dark' ? 'light' : 'dark');
      });
    }
    // react to OS theme change if user hasn't set a preference
    if (window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function (e) {
        if (!localStorage.getItem(THEME_KEY)) {
          applyTheme(e.matches ? 'dark' : 'light');
        }
      });
    }
  }

  function initLangSwitcher() {
    if (!window.SXS_i18n) return;
    document.querySelectorAll('[data-lang-btn]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        window.SXS_i18n.setLang(btn.getAttribute('data-lang-btn'));
      });
    });
  }

  function initMobileNav() {
    const btn = document.querySelector('[data-menu-btn]');
    const nav = document.querySelector('[data-header-nav]');
    if (!btn || !nav) return;

    function setOpen(open) {
      nav.classList.toggle('open', open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.setAttribute('aria-label', (window.SXS_i18n && window.SXS_i18n.t(open ? 'menu.close' : 'menu.open')) || (open ? 'Close menu' : 'Open menu'));
      if (open) {
        // never stack the doc switcher and the site menu on top of each other
        document.querySelectorAll('.docs-sidebar.open').forEach(function (sb) {
          sb.classList.remove('open');
          const t = sb.previousElementSibling;
          if (t && t.classList.contains('docnav-toggle')) t.setAttribute('aria-expanded', 'false');
        });
      }
    }
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-controls', 'site-nav');
    if (!nav.id) nav.id = 'site-nav';

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      setOpen(!nav.classList.contains('open'));
    });
    nav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { setOpen(false); });
    });
    // tapping anywhere outside closes the panel
    document.addEventListener('click', function (e) {
      if (!nav.classList.contains('open')) return;
      if (nav.contains(e.target) || btn.contains(e.target)) return;
      setOpen(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('open')) { setOpen(false); btn.focus(); }
    });
    window.addEventListener('resize', function () {
      if (window.innerWidth > 1024 && nav.classList.contains('open')) setOpen(false);
    });
  }

  function initScrollHeader() {
    const header = document.querySelector('.site-header');
    if (!header) return;
    let ticking = false;
    function update() {
      if (window.scrollY > 8) header.classList.add('scrolled');
      else header.classList.remove('scrolled');
      ticking = false;
    }
    window.addEventListener('scroll', function () {
      if (!ticking) { window.requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    update();
  }

  function initFadeIn() {
    const els = document.querySelectorAll('.fade-in');
    if (!els.length || !('IntersectionObserver' in window)) {
      els.forEach(function (el) { el.classList.add('visible'); });
      return;
    }
    const io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    els.forEach(function (el) { io.observe(el); });
  }

  function initCopyButtons() {
    document.addEventListener('click', function (e) {
      const btn = e.target.closest('[data-copy]');
      if (!btn) return;
      const text = btn.getAttribute('data-copy');
      if (!text) return;
      const done = function () {
        const orig = btn.textContent;
        btn.textContent = (window.SXS_i18n && window.SXS_i18n.t('copied')) || 'Copied';
        btn.classList.add('copied');
        setTimeout(function () { btn.textContent = orig; btn.classList.remove('copied'); }, 1500);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text); done(); });
      } else {
        fallbackCopy(text); done();
      }
    });
  }

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    document.body.removeChild(ta);
  }

  function initBackToTop() {
    const btn = document.querySelector('[data-back-to-top]');
    if (!btn) return;
    let ticking = false;
    function update() {
      if (window.scrollY > 600) btn.classList.add('visible');
      else btn.classList.remove('visible');
      ticking = false;
    }
    window.addEventListener('scroll', function () {
      if (!ticking) { window.requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    btn.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    update();
  }

  // highlight active sidebar link based on current path
  function initActiveSidebar() {
    const path = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    document.querySelectorAll('.side-link').forEach(function (link) {
      const href = (link.getAttribute('href') || '').split('/').pop().toLowerCase();
      if (href && href === path) link.classList.add('active');
    });
  }

  // build TOC from h2/h3 in .prose if a [data-toc] container exists
  // Only shows the current language's text (respects [data-lang] spans).
  function headingText(h) {
    const lang = (window.SXS_i18n && window.SXS_i18n.lang) || 'en';
    const span = h.querySelector('[data-lang="' + lang + '"]');
    return span ? span.textContent : h.textContent;
  }

  function buildTOC() {
    const container = document.querySelector('[data-toc]');
    if (!container) return;
    const prose = document.querySelector('.prose');
    if (!prose) return;
    const heads = prose.querySelectorAll('h2, h3');
    if (!heads.length) { container.style.display = 'none'; return; }
    const frag = document.createDocumentFragment();
    heads.forEach(function (h, i) {
      if (!h.id) h.id = 'sec-' + i;
      const a = document.createElement('a');
      a.href = '#' + h.id;
      a.textContent = headingText(h);
      a.className = 'toc-link' + (h.tagName === 'H3' ? ' toc-sub' : '');
      frag.appendChild(a);
    });
    container.innerHTML = '';
    container.appendChild(frag);

    // scroll-spy
    const links = container.querySelectorAll('.toc-link');
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            links.forEach(function (l) { l.classList.remove('active'); });
            const active = container.querySelector('a[href="#' + entry.target.id + '"]');
            if (active) active.classList.add('active');
          }
        });
      }, { rootMargin: '0px 0px -70% 0px' });
      heads.forEach(function (h) { io.observe(h); });
    }
  }

  function initAutoTOC() {
    buildTOC();
    // rebuild TOC when language changes so headings stay in the active language
    if (window.SXS_i18n) {
      const orig = window.SXS_i18n.apply;
      window.SXS_i18n.apply = function () {
        orig.apply(this, arguments);
        buildTOC();
      };
    }
  }

  /* Figures ship as a pair of screenshots (en / zh), because the app UI
   * itself is localised. Swap the file when the page language changes. */
  function applyFigureLang() {
    var lang = document.documentElement.lang || 'en';
    var zh = lang.indexOf('zh') === 0;
    document.querySelectorAll('img[data-en][data-zh]').forEach(function (img) {
      var src = zh ? img.getAttribute('data-zh') : img.getAttribute('data-en');
      if (img.getAttribute('src') !== src) img.setAttribute('src', src);
    });
    document.querySelectorAll('a.fig-zoom[data-en][data-zh]').forEach(function (a) {
      a.setAttribute('href', zh ? a.getAttribute('data-zh') : a.getAttribute('data-en'));
    });
  }

  /* ------------------------------------------------------------------
   * Figure lightbox: figures are downscaled to the prose column, so let
   * readers open the full-resolution WebP (and the animated one) in an
   * overlay. Falls back to a plain link when JS is unavailable.
   * ------------------------------------------------------------------ */
  function initFigureZoom() {
    var links = document.querySelectorAll('.doc-figure .fig-zoom');
    if (!links.length) return;

    var overlay = null;

    function close() {
      if (!overlay) return;
      overlay.classList.remove('open');
      document.body.style.overflow = '';
      var img = overlay.querySelector('img');
      setTimeout(function () { if (img) img.removeAttribute('src'); }, 200);
    }

    function open(href, alt, captionHTML) {
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'fig-lightbox';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.innerHTML = '<button class="fig-lb-close" type="button" aria-label="Close">&times;</button>' +
          '<div class="fig-lb-body"><img alt="" /><p class="fig-lb-cap"></p></div>';
        overlay.addEventListener('click', function (e) {
          if (e.target === overlay || e.target.classList.contains('fig-lb-close')) close();
        });
        document.body.appendChild(overlay);
        document.addEventListener('keydown', function (e) {
          if (e.key === 'Escape') close();
        });
      }
      var img = overlay.querySelector('img');
      img.src = href;
      img.alt = alt || '';
      overlay.querySelector('.fig-lb-cap').innerHTML = captionHTML || '';
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    }

    links.forEach(function (link) {
      link.addEventListener('click', function (e) {
        var figure = link.closest('.doc-figure');
        var img = link.querySelector('img');
        var cap = figure ? figure.querySelector('figcaption') : null;
        var visibleCap = null;
        if (cap) {
          var spans = cap.querySelectorAll('[data-lang]');
          if (spans.length) {
            Array.prototype.forEach.call(spans, function (sp) {
              if (sp.classList.contains('show')) visibleCap = sp.innerHTML;
            });
            if (!visibleCap) visibleCap = cap.innerHTML;
          } else {
            visibleCap = cap.innerHTML;
          }
        }
        e.preventDefault();
        open(link.getAttribute('href'), img ? img.getAttribute('alt') : '', visibleCap);
      });
    });
  }

  function boot() {
    initTheme();
    if (window.SXS_i18n) window.SXS_i18n.init();
    initLangSwitcher();
    initMobileNav();
    initScrollHeader();
    initFadeIn();
    initCopyButtons();
    initBackToTop();
    initActiveSidebar();
    initAutoTOC();
    applyFigureLang();
    initFigureZoom();
    document.addEventListener('localeChanged', applyFigureLang);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
